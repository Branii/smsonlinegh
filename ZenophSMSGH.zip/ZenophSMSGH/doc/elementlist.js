
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","ZenophSMSGH"],["c","ZenophSMSGH_Exception"],["c","ZenophSMSGH_MessageResponse"],["c","ZenophSMSGH_MESSAGETYPE"],["c","ZenophSMSGH_RESPONSECODE"]];
